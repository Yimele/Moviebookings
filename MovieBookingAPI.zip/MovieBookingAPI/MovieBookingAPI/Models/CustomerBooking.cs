﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace MovieBookingAPI.Models
{
    public class CustomerBooking
    {
        [Key]
        public int CustomerBookingId { get; set; }
        public int BookingId { get; set; }
        public int CustomerId { get; set; }
        public int CostPrice { get; set; }

        public virtual Booking Booking { get; set; }
        public virtual Customer Customer { get; set; }
    }
}