﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace MovieBookingAPI.Models
{
    public class Booking
    {
        [Key]
        
        public int BookingId { get; set; }
        public string MovieTitle { get; set; }
        public int CostPrice { get; set; }

        public virtual ICollection<CustomerBooking> CustomerBookings { get; set; }
    }
}