namespace MovieBookingAPI.Migrations
{
    using Models;
    using System;
    using System.Data.Entity;
    using System.Data.Entity.Migrations;
    using System.Linq;

    internal sealed class Configuration : DbMigrationsConfiguration<MovieBookingAPI.Models.MovieBookingAPIContext>
    {
        public Configuration()
        {
            AutomaticMigrationsEnabled = false;
        }

        protected override void Seed(MovieBookingAPI.Models.MovieBookingAPIContext context)
        {
            //  This method will be called after migrating to the latest version.
            context.Customers.AddOrUpdate(p => p.CustomerId,
            new Customer { LastName = "Carson", FirstName = "Alexander", Address = "Balbriggan", MovieTittle = "Love him", BookingDate = DateTime.Parse("2005-09-01"), PhoneNumber = "08993414304" },
            new Customer { LastName = "John", FirstName = "Pascal", Address = "Sword", MovieTittle = "Home Time", BookingDate = DateTime.Parse("2007-02-20"), PhoneNumber = "08993414304" }
             );
            //  You can use the DbSet<T>.AddOrUpdate() helper extension method 
            //  to avoid creating duplicate seed data. E.g.
            //
            context.Bookings.AddOrUpdate(w => w.BookingId,
            new Booking { MovieTitle = "Love Him", CostPrice = 30 },
            new Booking { MovieTitle = "Home Time", CostPrice = 20 }
            );

            context.CustomerBookings.AddOrUpdate(r => r.CustomerBookingId,
            new CustomerBooking { CustomerId = 1, BookingId = 1050, CostPrice = 30 },
            new CustomerBooking { CustomerId = 2, BookingId = 897, CostPrice = 20 }
            );
            //    context.People.AddOrUpdate(
            //      p => p.FullName,
            //      new Person { FullName = "Andrew Peters" },
            //      new Person { FullName = "Brice Lambson" },
            //      new Person { FullName = "Rowan Miller" }
            //    );
            //
        }
    }
}
