namespace MovieBookingAPI.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class Initial : DbMigration
    {
        public override void Up()
        {
            //CreateTable(
            //    "dbo.Bookings",
            //    c => new
            //        {
            //            BookingId = c.Int(nullable: false, identity: true),
            //            MovieTitle = c.String(),
            //            CostPrice = c.Int(nullable: false),
            //        })
            //    .PrimaryKey(t => t.BookingId);
            
            //CreateTable(
            //    "dbo.CustomerBookings",
            //    c => new
            //        {
            //            CustomerBookingId = c.Int(nullable: false, identity: true),
            //            BookingId = c.Int(nullable: false),
            //            CustomerId = c.Int(nullable: false),
            //            CostPrice = c.Int(nullable: false),
            //        })
            //    .PrimaryKey(t => t.CustomerBookingId)
            //    .ForeignKey("dbo.Bookings", t => t.BookingId, cascadeDelete: true)
            //    .ForeignKey("dbo.Customers", t => t.CustomerId, cascadeDelete: true)
            //    .Index(t => t.BookingId)
            //    .Index(t => t.CustomerId);
            
            //CreateTable(
            //    "dbo.Customers",
            //    c => new
            //        {
            //            CustomerId = c.Int(nullable: false, identity: true),
            //            LastName = c.String(),
            //            FirstName = c.String(),
            //            Address = c.String(),
            //            MovieTittle = c.String(),
            //            BookingDate = c.DateTime(nullable: false),
            //            PhoneNumber = c.String(),
            //        })
            //    .PrimaryKey(t => t.CustomerId);
            
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.CustomerBookings", "CustomerId", "dbo.Customers");
            DropForeignKey("dbo.CustomerBookings", "BookingId", "dbo.Bookings");
            DropIndex("dbo.CustomerBookings", new[] { "CustomerId" });
            DropIndex("dbo.CustomerBookings", new[] { "BookingId" });
            DropTable("dbo.Customers");
            DropTable("dbo.CustomerBookings");
            DropTable("dbo.Bookings");
        }
    }
}
