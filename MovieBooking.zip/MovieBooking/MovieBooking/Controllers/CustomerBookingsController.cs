﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using MovieBooking.DAL;
using MovieBooking.Models;

namespace MovieBooking.Controllers
{
    public class CustomerBookingsController : Controller
    {
        private MovieContext db = new MovieContext();

        // GET: CustomerBookings
        public ActionResult Index()
        {
            var customerBooking = db.CustomerBooking.Include(c => c.Booking).Include(c => c.Customer);
            return View(customerBooking.ToList());
        }

        // GET: CustomerBookings/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            CustomerBooking customerBooking = db.CustomerBooking.Find(id);
            if (customerBooking == null)
            {
                return HttpNotFound();
            }
            return View(customerBooking);
        }

        // GET: CustomerBookings/Create
        public ActionResult Create()
        {
            ViewBag.BookingID = new SelectList(db.Booking, "BookingID", "MovieTitle");
            ViewBag.CustomerID = new SelectList(db.Customer, "ID", "LastName");
            return View();
        }

        // POST: CustomerBookings/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "CustomerBookingID,BookingID,CustomerID,CostPrice")] CustomerBooking customerBooking)
        {
            if (ModelState.IsValid)
            {
                db.CustomerBooking.Add(customerBooking);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            ViewBag.BookingID = new SelectList(db.Booking, "BookingID", "MovieTitle", customerBooking.BookingID);
            ViewBag.CustomerID = new SelectList(db.Customer, "ID", "LastName", customerBooking.CustomerID);
            return View(customerBooking);
        }

        // GET: CustomerBookings/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            CustomerBooking customerBooking = db.CustomerBooking.Find(id);
            if (customerBooking == null)
            {
                return HttpNotFound();
            }
            ViewBag.BookingID = new SelectList(db.Booking, "BookingID", "MovieTitle", customerBooking.BookingID);
            ViewBag.CustomerID = new SelectList(db.Customer, "ID", "LastName", customerBooking.CustomerID);
            return View(customerBooking);
        }

        // POST: CustomerBookings/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "CustomerBookingID,BookingID,CustomerID,CostPrice")] CustomerBooking customerBooking)
        {
            if (ModelState.IsValid)
            {
                db.Entry(customerBooking).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            ViewBag.BookingID = new SelectList(db.Booking, "BookingID", "MovieTitle", customerBooking.BookingID);
            ViewBag.CustomerID = new SelectList(db.Customer, "ID", "LastName", customerBooking.CustomerID);
            return View(customerBooking);
        }

        // GET: CustomerBookings/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            CustomerBooking customerBooking = db.CustomerBooking.Find(id);
            if (customerBooking == null)
            {
                return HttpNotFound();
            }
            return View(customerBooking);
        }

        // POST: CustomerBookings/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            CustomerBooking customerBooking = db.CustomerBooking.Find(id);
            db.CustomerBooking.Remove(customerBooking);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
