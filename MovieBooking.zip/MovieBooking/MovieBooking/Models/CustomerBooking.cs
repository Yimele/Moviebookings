﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace MovieBooking.Models
{
    public class CustomerBooking
    {
        [Display(Name = "Customer Booking ID")]
        public int CustomerBookingID { get; set; }
        [Display(Name = "Booking ID")]
        public int BookingID { get; set; }
        [Display(Name = "Customer ID")]
        public int CustomerID { get; set; }
        [Display(Name = "Cost Price")]
        public int CostPrice { get; set; }

        public virtual Booking Booking { get; set; }
        public virtual Customer Customer { get; set; }
    }
}