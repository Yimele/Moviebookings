﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace MovieBooking.Models
{
    public class Booking
    {
        [System.ComponentModel.DataAnnotations.Schema.DatabaseGenerated(System.ComponentModel.DataAnnotations.Schema.DatabaseGeneratedOption.None)]
        [Display(Name = "Booking ID")]
        public int BookingID { get; set; }
        [Display(Name = "Movie Title")]
        public string MovieTitle { get; set; }
        [Display(Name = "Cost Price")]
        public int CostPrice { get; set; }

        public virtual ICollection<CustomerBooking> CustomerBookings { get; set; }
    }
}