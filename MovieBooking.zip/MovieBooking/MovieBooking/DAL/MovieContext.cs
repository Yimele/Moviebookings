﻿using MovieBooking.Models;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Data.Entity.ModelConfiguration.Conventions;
using System.Linq;
using System.Web;

namespace MovieBooking.DAL
{
    public class MovieContext : DbContext
    {

        public MovieContext() : base("MovieContext")
        {
        }

        public DbSet<Customer> Customer { get; set; }
        public DbSet<CustomerBooking> CustomerBooking { get; set; }
        public DbSet<Booking> Booking { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Conventions.Remove<PluralizingTableNameConvention>();
        }
    }
}