﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.Entity;
using MovieBooking.Models;

namespace MovieBooking.DAL
{
    public class MovieInitializer : System.Data.Entity.DropCreateDatabaseIfModelChanges<MovieContext>
    {
        protected override void Seed(MovieContext context)
        {
            var customers = new List<Customer>
            {
           new Customer{LastName="Carson",FirstName="Alexander", Address="Balbriggan", MovieTittle="Love him", BookingDate=DateTime.Parse("2005-09-01"), PhoneNumber="08993414304"},
            new Customer{LastName="John",FirstName="Pascal", Address="Sword", MovieTittle="Home Time", BookingDate=DateTime.Parse("2007-02-20"), PhoneNumber="08993414304"}

            };

            customers.ForEach(s => context.Customer.Add(s));
            context.SaveChanges();
            var bookings = new List<Booking>
            {
           new Booking{BookingID=1050,MovieTitle="Love Him",CostPrice=30,},
            new Booking{BookingID=9356,MovieTitle="Home Time",CostPrice=20,},
            };
            bookings.ForEach(s => context.Booking.Add(s));
            context.SaveChanges();
            var customerBookings = new List<CustomerBooking>
            {
            new CustomerBooking{CustomerID=1,BookingID=1050,CostPrice=30},
            new CustomerBooking{CustomerID=2,BookingID=897,CostPrice=20},
            };
            customerBookings.ForEach(s => context.CustomerBooking.Add(s));
            context.SaveChanges();
        }
    }
}